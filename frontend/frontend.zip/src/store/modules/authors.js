import { AUTHORS, UI } from '../types'
import * as authorsApi from '@/api/authorsApi'

export default {
    namespaced: true,
    state: () => ({
        list: [],
        current: null,
        loading: false,
        error: null,
    }),

    getters: {
        authorsList: (state) => state.list,
        currentAuthor: (state) => state.current,
        authorsLoading: (state) => state.loading,
        authorsError: (state) => state.error,
        getAuthorById: (state) => (id) => {
            return state.list.find((author) => author.id === id)
        },
    },

    mutations: {
        [AUTHORS.SET_LIST](state, authors) {
            state.list = authors
        },
        [AUTHORS.SET_CURRENT](state, author) {
            state.current = author
        },
        [UI.SET_LOADING](state, loading) {
            state.loading = loading
        },
        [UI.SET_ERROR](state, error) {
            state.error = error
        },
    },

    actions: {
        async fetchAuthors({ commit }) {
            commit(UI.SET_LOADING, true)
            try {
                const authors = await authorsApi.fetchAuthors()
                commit(AUTHORS.SET_LIST, authors)
            } catch (error) {
                commit(UI.SET_ERROR, error)
            } finally {
                commit(UI.SET_LOADING, false)
            }
        },

        async fetchAuthorById({ commit }, id) {
            commit(UI.SET_LOADING, true)
            try {
                const author = await authorsApi.fetchAuthorDetails(id)
                commit(AUTHORS.SET_CURRENT, author)
            } catch (error) {
                commit(UI.SET_ERROR, error)
            } finally {
                commit(UI.SET_LOADING, false)
            }
        },

        async createAuthor({ commit }, authorData) {
            commit(UI.SET_LOADING, true)
            try {
                const author = await authorsApi.createAuthor(authorData)
                commit(AUTHORS.SET_CURRENT, author)
                return author
            } catch (error) {
                commit(UI.SET_ERROR, error)
                throw error
            } finally {
                commit(UI.SET_LOADING, false)
            }
        },
    },
}
