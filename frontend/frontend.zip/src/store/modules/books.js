import { BOOKS, UI } from '../types'
import * as booksApi from '@/api/booksApi'

export default {
    namespaced: true,
    state: () => ({
        list: [],
        current: null,
        loading: false,
        error: null,
        filters: {
            category: null,
            search: '',
            sortBy: 'title',
        },
        pagination: {
            page: 1,
            perPage: 20,
            total: 0,
        },
    }),

    getters: {
        booksList: (state) => state.list,
        currentBook: (state) => state.current,
        booksLoading: (state) => state.loading,
        booksError: (state) => state.error,
        filteredBooks: (state) => {
            let result = [...state.list]
            if (state.filters.search) {
                result = result.filter((book) => book.title.toLowerCase().includes(state.filters.search.toLowerCase()))
            }
            if (state.filters.category) {
                result = result.filter((book) => book.category === state.filters.category)
            }
            if (state.filters.sortBy) {
                result.sort((a, b) => a[state.filters.sortBy].localeCompare(b[state.filters.sortBy]))
            }
            return result
        },
    },

    mutations: {
        [BOOKS.SET_BOOKS](state, books) {
            state.list = books
        },
        [BOOKS.SET_CURRENT](state, book) {
            state.current = book
        },
        [UI.SET_LOADING](state, loading) {
            state.loading = loading
        },
        [UI.SET_ERROR](state, error) {
            state.error = error
        },
        setFilters(state, filters) {
            state.filters = { ...state.filters, ...filters }
        },
        setPagination(state, pagination) {
            state.pagination = { ...state.pagination, ...pagination }
        },
    },

    actions: {
        async fetchBooks({ commit, state }) {
            commit(UI.SET_LOADING, true)
            try {
                const { books, total } = await booksApi.fetchBooks(state.pagination.page, state.pagination.perPage)
                commit(BOOKS.SET_BOOKS, books)
                commit('setPagination', { total })
            } catch (error) {
                commit(UI.SET_ERROR, error)
            } finally {
                commit(UI.SET_LOADING, false)
            }
        },

        async fetchBookById({ commit }, id) {
            commit(UI.SET_LOADING, true)
            try {
                const book = await booksApi.fetchBookDetails(id)
                commit(BOOKS.SET_CURRENT, book)
            } catch (error) {
                commit(UI.SET_ERROR, error)
            } finally {
                commit(UI.SET_LOADING, false)
            }
        },
    },
}
