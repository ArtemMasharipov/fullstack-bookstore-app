import baseApi from './baseApi'

export const fetchBooks = async (page = 1, limit = 10) => {
    const response = await baseApi.get('/books', { params: { page, limit } })
    return response.data
}

export const fetchBookDetails = async (bookId) => {
    const response = await baseApi.get(`/books/${bookId}`)
    return response.data
}

export const createBook = async (bookData) => {
    const response = await baseApi.post('/books', bookData)
    return response.data
}

export const updateBook = async (bookId, bookData) => {
    const response = await baseApi.put(`/books/${bookId}`, bookData)
    return response.data
}

export const deleteBook = async (bookId) => {
    const response = await baseApi.delete(`/books/${bookId}`)
    return response.data
}
