<template>
    <form class="auth-form" @submit.prevent="handleSubmit">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input id="name" v-model="form.name" type="text" required />
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input id="email" v-model="form.email" type="email" required />
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input id="password" v-model="form.password" type="password" required />
        </div>

        <button type="submit" class="btn btn-primary" :disabled="loading">
            {{ loading ? 'Creating Account...' : 'Register' }}
        </button>

        <p v-if="error" class="error-message">{{ error }}</p>
    </form>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
    name: 'RegisterForm',

    props: {
        loading: {
            type: Boolean,
            default: false,
        },
    },

    data() {
        return {
            form: {
                name: '',
                email: '',
                password: '',
            },
        }
    },

    computed: {
        ...mapState(['error', 'loading']),
    },

    methods: {
        ...mapActions(['register']),
        async handleSubmit() {
            try {
                await this.register(this.form);
                this.$router.push('/');
            } catch (error) {
                console.error('Registration failed:', error);
            }
        },
    },
}
</script>

<style scoped>
.auth-form {
    width: 100%;
    max-width: 400px;
    margin: 0 auto;
}

.btn {
    width: 100%;
    margin-top: 1rem;
}

.error-message {
    color: red;
    margin-top: 1rem;
}
</style>
