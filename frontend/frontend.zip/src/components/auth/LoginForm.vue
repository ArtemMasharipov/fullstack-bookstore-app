<template>
    <div class="login-page">
        <div class="login-container">
            <h2>Login</h2>
            <form class="auth-form" @submit.prevent="handleSubmit">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" v-model="form.email" type="email" required />
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" v-model="form.password" type="password" required />
                </div>

                <button type="submit" class="btn btn-primary" :disabled="loading">
                    {{ loading ? 'Logging in...' : 'Login' }}
                </button>

                <p v-if="error" class="error-message">{{ error }}</p>
                <p class="register-link">
                    Don't have an account?
                    <router-link to="/register">Register</router-link>
                </p>
            </form>
        </div>
    </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'

export default {
    name: 'LoginPage',
    data() {
        return {
            form: {
                email: '',
                password: '',
            },
        };
    },
    computed: {
        ...mapState(['error', 'loading']),
    },
    methods: {
        ...mapActions(['login']),
        async handleSubmit() {
            try {
                await this.login(this.form);
                this.$router.push('/');
            } catch (error) {
                console.error('Login failed:', error);
            }
        },
    },
}
</script>

<style scoped>
.login-page {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: var(--gray-light);
}

.login-container {
    width: 100%;
    max-width: 400px;
    padding: 2rem;
    background: var(--white);
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.auth-form {
    width: 100%;
    max-width: 400px;
    margin: 0 auto;
}

.btn {
    width: 100%;
    margin-top: 1rem;
}

.error-message {
    color: var(--error-color);
    margin-top: 1rem;
}

.register-link {
    text-align: center;
    margin-top: 1rem;

    a {
        color: var(--primary-color);
        text-decoration: none;

        &:hover {
            text-decoration: underline;
        }
    }
}
</style>
