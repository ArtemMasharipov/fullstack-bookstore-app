import indexRouter from '../src/v1/routes/index.mjs';
import authRoutes from '../src/v1/routes/authRoutes.mjs';
import userRoutes from '../src/v1/routes/userRoutes.mjs';
import authorRoutes from '../src/v1/routes/authorRoutes.mjs';
import bookRoutes from '../src/v1/routes/bookRoutes.mjs';
import roleRoutes from '../src/v1/routes/roleRoutes.mjs';

export const setupRoutes = (app) => {
  app.use('/', indexRouter);
  app.use('/auth', authRoutes);
  app.use('/users', userRoutes);
  app.use('/authors', authorRoutes);
  app.use('/books', bookRoutes);
  app.use('/roles', roleRoutes);
};
