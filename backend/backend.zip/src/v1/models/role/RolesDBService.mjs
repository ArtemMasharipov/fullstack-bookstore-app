import MongooseCRUDManager from '../MongooseCRUDManager.mjs';
import Role from './roleModel.mjs';
import { ROLES, getRolePermissions } from '../../../../services/permissions-handler/roleConfig.mjs';
import UsersDBService from '../user/UsersDBService.mjs';

class RolesDBService extends MongooseCRUDManager {
  constructor() {
    super(Role);
    this.defaultRoles = Object.values(ROLES);
  }

  async initializeDefaultRolesAndAdmin() {
    try {
      const roles = await Promise.all(
        this.defaultRoles.map(roleName => this.initializeRole(roleName))
      );

      await this.createAdminUser();
      
      return roles;
    } catch (error) {
      throw new Error(`Role initialization failed: ${error.message}`);
    }
  }

  async initializeRole(roleName) {
    try {
      const permissions = getRolePermissions(roleName);
      return await this.model.findOneAndUpdate(
        { name: roleName },
        { 
          name: roleName,
          permissions 
        },
        { upsert: true, new: true }
      );
    } catch (error) {
      throw new Error(`Failed to initialize role ${roleName}: ${error.message}`);
    }
  }

  async createAdminUser() {
    const { DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD, DEFAULT_ADMIN_USERNAME } = process.env;

    if (!DEFAULT_ADMIN_EMAIL || !DEFAULT_ADMIN_PASSWORD || !DEFAULT_ADMIN_USERNAME) {
      throw new Error('Admin credentials not properly configured in environment');
    }

    try {
      const adminRole = await this.model.findOne({ name: ROLES.ADMIN });
      await UsersDBService.createUser({
        username: DEFAULT_ADMIN_USERNAME,
        email: DEFAULT_ADMIN_EMAIL,
        password: DEFAULT_ADMIN_PASSWORD,
        role: ROLES.ADMIN,
        permissions: adminRole.permissions
      });
      console.log('Admin user created successfully');
    } catch (error) {
      if (error.message.includes('User with this email already exists')) {
        console.log('Admin user already exists');
        return;
      }
      throw error;
    }
  }
}

export default new RolesDBService();
