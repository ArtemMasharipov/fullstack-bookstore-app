import User from './userModel.mjs';
import { ROLES } from '../../../../services/permissions-handler/roleConfig.mjs';

class UsersDBService {
  async createUser({ username, email, password, role, permissions }) {
    try {
      if (!Object.values(ROLES).includes(role)) {
        throw new Error(`Invalid role: ${role}`);
      }

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        throw new Error('User with this email already exists');
      }

      const user = new User({ username, email, password, role, permissions });
      await user.save();
      return user;
    } catch (error) {
      throw new Error(`Error creating user: ${error.message}`);
    }
  }

  async findByEmail(email) {
    try {
      return await User.findOne({ email });
    } catch (error) {
      throw new Error(`Error finding user by email: ${error.message}`);
    }
  }
}

export default new UsersDBService();
