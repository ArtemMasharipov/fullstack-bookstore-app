import MongooseCRUDManager from '../MongooseCRUDManager.mjs';
import Author from './authorModel.mjs';

class AuthorsDBService extends MongooseCRUDManager {
  constructor() {
    super(Author);
  }

  async getAuthorWithBooks(authorId) {
    try {
      return await this.model
        .findById(authorId)
        .populate('books', 'title publicationYear isbn category');
    } catch (error) {
      throw new Error(`Error fetching author with books: ${error.message}`);
    }
  }
}

export default new AuthorsDBService();
