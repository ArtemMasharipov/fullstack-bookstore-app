import MongooseCRUDManager from '../MongooseCRUDManager.mjs';
import Book from './bookModel.mjs';

class BooksDBService extends MongooseCRUDManager {
  constructor() {
    super(Book);
  }

  async searchBooks(query) {
    const { title, author, category, minYear, maxYear, isbn } = query;
    const filter = {};

    if (title) {
      filter.title = new RegExp(title, 'i');
    }

    if (author) {
      filter['author.name'] = new RegExp(author, 'i'); // Поиск по имени
    }

    if (category) {
      filter.category = new RegExp(category, 'i');
    }

    if (minYear || maxYear) {
      filter.publicationYear = {
        ...(minYear ? { $gte: Number(minYear) } : {}),
        ...(maxYear ? { $lte: Number(maxYear) } : {}),
      };
    }

    if (isbn) {
      filter.isbn = isbn;
    }

    try {
      return await this.model
        .find(filter)
        .populate('author', 'name biography')
        .select('title publicationYear isbn category');
    } catch (error) {
      throw new Error('Error searching books: ' + error.message);
    }
  }
}

export default new BooksDBService();
