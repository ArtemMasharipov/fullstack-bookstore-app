import BooksDBService from '../models/book/BooksDBService.mjs';

export const getAllBooks = async (req, res) => {
  try {
    const books = await BooksDBService.getList();
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch books' });
  }
};

export const searchBooks = async (req, res) => {
  try {
    const books = await BooksDBService.searchBooks(req.query);
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Failed to search books' });
  }
};

export const getBooksByCategory = async (req, res) => {
  try {
    const books = await BooksDBService.getBooksByCategory(req.params.category);
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch books by category' });
  }
};

export const getBooksByAuthor = async (req, res) => {
  try {
    const books = await BooksDBService.getBooksByAuthor(req.params.authorId);
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch books by author' });
  }
};

export const getBookById = async (req, res) => {
  try {
    const book = await BooksDBService.getById(req.params.id, ['author']);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    res.json(book);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch book' });
  }
};

export const createBook = async (req, res) => {
  try {
    const newBook = await BooksDBService.create(req.body);
    res.status(201).json(newBook);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create book' });
  }
};

export const updateBook = async (req, res) => {
  try {
    const updatedBook = await BooksDBService.update(req.params.id, req.body);
    if (!updatedBook) return res.status(404).json({ error: 'Book not found' });
    res.json(updatedBook);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update book' });
  }
};

export const deleteBook = async (req, res) => {
  try {
    const deletedBook = await BooksDBService.deleteById(req.params.id);
    if (!deletedBook) return res.status(404).json({ error: 'Book not found' });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete book' });
  }
};
