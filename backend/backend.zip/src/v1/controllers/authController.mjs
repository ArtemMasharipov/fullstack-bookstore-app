import UsersDBService from '../models/user/UsersDBService.mjs';
import RolesDBService from '../models/role/RolesDBService.mjs';
import { prepareToken } from '../../../services/jwtHelpers.mjs';
import { validationResult } from 'express-validator';

class AuthController {
  static async login(req, res) {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and Password are required' });
    }

    try {
      const user = await UsersDBService.model
        .findOne({ email })
        .populate('role');
      if (!user || !(await user.isValidPassword(password))) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }

      const token = prepareToken(
        { id: user._id, role: user.role.name },
        req.headers,
      );

      res.status(200).json({
        message: 'Login successful',
        token,
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }

  static async register(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, role } = req.body;

    try {
      const userExists = await UsersDBService.model.findOne({ email });
      if (userExists) {
        return res.status(409).json({ error: 'User already exists' });
      }

      const assignedRole = await RolesDBService.model.findOne({
        name: role || 'user',
      });
      if (!assignedRole) {
        return res.status(400).json({ error: 'Invalid role provided.' });
      }

      const newUser = await UsersDBService.createUser({
        email,
        password,
        role: assignedRole.name,
      });

      res
        .status(201)
        .json({ message: 'User registered successfully', user: newUser });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
}

export default AuthController;
