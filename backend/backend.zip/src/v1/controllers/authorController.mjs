import AuthorsDBService from '../models/author/AuthorsDBService.mjs';

export const getAllAuthors = async (req, res) => {
  try {
    const authors = await AuthorsDBService.getList();
    res.json(authors);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch authors' });
  }
};

export const getAuthorWithBooks = async (req, res) => {
  try {
    const author = await AuthorsDBService.getAuthorWithBooks(req.params.id);
    if (!author) return res.status(404).json({ error: 'Author not found' });
    res.json(author);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch author with books' });
  }
};

export const createAuthor = async (req, res) => {
  try {
    const newAuthor = await AuthorsDBService.create(req.body);
    res.status(201).json(newAuthor);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create author' });
  }
};

export const updateAuthor = async (req, res) => {
  try {
    const updatedAuthor = await AuthorsDBService.update(
      req.params.id,
      req.body,
    );
    if (!updatedAuthor)
      return res.status(404).json({ error: 'Author not found' });
    res.json(updatedAuthor);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update author' });
  }
};

export const deleteAuthor = async (req, res) => {
  try {
    const deletedAuthor = await AuthorsDBService.deleteById(req.params.id);
    if (!deletedAuthor)
      return res.status(404).json({ error: 'Author not found' });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete author' });
  }
};
