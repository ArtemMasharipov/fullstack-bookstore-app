import { checkSchema } from 'express-validator';

const authorValidationSchema = checkSchema({
  name: {
    trim: true,
    escape: true,
    isLength: {
      options: { min: 2, max: 100 },
      errorMessage: 'Name must be between 2 and 100 characters long.',
    },
    notEmpty: {
      errorMessage: 'Name is required.',
    },
  },
  biography: {
    optional: true,
    trim: true,
    escape: true,
    isLength: {
      options: { max: 2000 },
      errorMessage: 'Biography cannot exceed 2000 characters.',
    },
  },
});

export default authorValidationSchema;
