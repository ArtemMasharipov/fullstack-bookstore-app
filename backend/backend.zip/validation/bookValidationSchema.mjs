import { checkSchema } from 'express-validator';

const bookValidationSchema = checkSchema({
  title: {
    trim: true,
    escape: true,
    isLength: {
      options: { min: 2, max: 100 },
      errorMessage: 'Title must be between 2 and 100 characters long.',
    },
    notEmpty: {
      errorMessage: 'Title is required.',
    },
  },
  author: {
    trim: true,
    escape: true,
    notEmpty: {
      errorMessage: 'Author is required.',
    },
  },
  isbn: {
    isISBN: {
      errorMessage: 'Invalid ISBN format.',
    },
    notEmpty: {
      errorMessage: 'ISBN is required.',
    },
  },
  price: {
    isNumeric: {
      errorMessage: 'Price must be a number.',
    },
    custom: {
      options: (value) => value > 0,
      errorMessage: 'Price must be greater than 0.',
    },
  },
  category: {
    optional: true,
    trim: true,
    escape: true,
    isLength: {
      options: { min: 2, max: 30 },
      errorMessage: 'Category must be between 2 and 30 characters long.',
    },
  },
  description: {
    optional: true,
    trim: true,
    escape: true,
    isLength: {
      options: { max: 500 },
      errorMessage: 'Description cannot exceed 500 characters.',
    },
  },
});

export default bookValidationSchema;
