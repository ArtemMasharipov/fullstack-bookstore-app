export const RESOURCE_TYPES = {
  BOOK: 'book',
  AUTHOR: 'author',
  USER: 'user',
  ROLE: 'role'
};

export const ACTION_TYPES = {
  CREATE: 'create',
  READ: 'read',
  UPDATE: 'update',
  DELETE: 'delete'
};

export const generatePermission = (action, resource) => `${action}:${resource}`;

export const PERMISSIONS = Object.values(RESOURCE_TYPES).flatMap(resource =>
  Object.values(ACTION_TYPES).map(action => generatePermission(action, resource))
);